# Initialize libraries
from js import *
from pyodide.ffi import create_proxy as CP

# Main processors
## Global variables & functions
isRunningTimer = False
timerHTML = document.querySelector('[class="timer"]')
timerButtonHTML = document.querySelector('button[name="timer"]')

isRunningAlarm = False
alarmHTML = document.querySelector('[class="alarm"]')
alarmButtonHTML = document.querySelector('button[name="alarm"]')

isRunningStopwatch = False
stopwatchHTML = document.querySelector('[class="stopwatch"]')
stopwatchButtonHTML = document.querySelector('button[name="stopwatch"]')
stopwatchSwitch = document.querySelector('button[class="stopwatchSwitch"]')
stopwatchReset = document.querySelector('button[class="stopwatchReset"]')
stopwatchTimeLabel = document.querySelector('label[class="stopwatchTimeLabel"]')
stopwatchSave = document.querySelector('button[class="stopwatchSave"]')
stopwatchTable = document.querySelector('table[class="stopwatchTable"]')
stopwatchInterval = 0
stopwatchTotal = 0
stopwatchLastSave = 0
stopwatchON = False

def FORMAT(TOTAL):
    TOTAL /= 1000;
    HOUR = str(int(TOTAL / 60 / 60))
    if (len(HOUR) == 1):
        HOUR = "0" + HOUR
    MINUTE = str(int(TOTAL % 3600 / 60))
    if (len(MINUTE) == 1):
        MINUTE = "0" + MINUTE;
    SECOND = format(TOTAL % 60, ".2f")
    if (len(SECOND) == 4):
        SECOND = "0" + SECOND
    return ":".join([HOUR, MINUTE, SECOND])

## Timer
def run_timer(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    if (isRunningAlarm):
        terminate_alarm()
    if (isRunningStopwatch):
        terminate_stopwatch()
    isRunningTimer = True
    timerHTML.hidden = False

def terminate_timer(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    isRunningTimer = False
    timerHTML.hidden = True

## Alarm
def run_alarm(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    if (isRunningTimer):
        terminate_timer()
    if (isRunningStopwatch):
        terminate_stopwatch()
    isRunningAlarm = True
    alarmHTML.hidden = False

def terminate_alarm(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    isRunningAlarm = False
    alarmHTML.hidden = True

## Stopwatch
def switch_stopwatch(event):
    global stopwatchON
    global stopwatchInterval
    if (stopwatchON):
        stopwatchON = False
        stopwatchSwitch.innerText = 'Start'
        clearInterval(stopwatchInterval)
    else:
        stopwatchON = True
        stopwatchSwitch.innerText = 'Pause'
        def process_stopwatch_time():
            global stopwatchTotal
            stopwatchTotal += 10
            stopwatchTimeLabel.innerText = FORMAT(stopwatchTotal)
        stopwatchInterval = setInterval(CP(process_stopwatch_time), 10)

def reset_stopwatch(event):
    global stopwatchON
    global stopwatchTotal
    if (stopwatchON):
        stopwatchSwitch.click()
    stopwatchTotal = 0
    stopwatchTimeLabel.innerText = FORMAT(0)
    stopwatchTable.innerHTML = '<tr><th>Laps</th><th>Time</th><th>Total</th></tr>'

def save_stopwatch(event):
    global stopwatchTotal
    global stopwatchLastSave
    row = document.createElement('tr')
    row.appendChild(document.createElement('td'))
    row.appendChild(document.createElement('td'))
    row.appendChild(document.createElement('td'))
    row.children[0].innerText = stopwatchTable.children.length
    row.children[1].innerText = FORMAT(stopwatchTotal - stopwatchLastSave)
    row.children[2].innerText = FORMAT(stopwatchTotal)
    stopwatchTable.appendChild(row)
    stopwatchLastSave = stopwatchTotal

def run_stopwatch(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    if (isRunningTimer):
        terminate_timer()
    if (isRunningAlarm):
        terminate_alarm()
    isRunningStopwatch = True
    stopwatchHTML.hidden = False

def terminate_stopwatch(*event):
    global isRunningTimer
    global isRunningAlarm
    global isRunningStopwatch
    isRunningStopwatch = False
    stopwatchHTML.hidden = True

stopwatchSwitch.onclick = CP(switch_stopwatch)
stopwatchReset.onclick = CP(reset_stopwatch)
stopwatchSave.onclick = CP(save_stopwatch)

# Start app
timerButtonHTML.onclick = CP(run_timer)
alarmButtonHTML.onclick = CP(run_alarm)
stopwatchButtonHTML.onclick = CP(run_stopwatch)
stopwatchButtonHTML.click()
